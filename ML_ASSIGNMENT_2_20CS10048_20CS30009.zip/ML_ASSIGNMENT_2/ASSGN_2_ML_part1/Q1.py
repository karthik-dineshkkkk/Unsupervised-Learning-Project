from sklearn.decomposition import PCA
from sklearn.preprocessing import MinMaxScaler
from numpy import genfromtxt
import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
import math
from sklearn.metrics.cluster import normalized_mutual_info_score as nmi

def recalculate_clusters(X, Y_pred, centroids, k):
    """ Recalculates the clusters """
    # Initiate empty clusters
    clusters = {}
    # Set the range for value of k (number of centroids)
    for i in range(k):
        clusters[i] = []
    for data in X:
        euc_dist = []
        for j in range(k):
            euc_dist.append(np.linalg.norm(data - centroids[j]))
        # Append the cluster of data to the dictionary
        clusters[euc_dist.index(min(euc_dist))].append(data)
        centroid = int((np.where(euc_dist[:] == min(euc_dist))[0]))
        Y_pred.append(centroid)
    return clusters

def recalculate_centroids(centroids, clusters, k):
    """ Recalculates the centroid position based on the plot """
    for i in range(k):
        centroids[i] = np.average(clusters[i], axis=0)
    return centroids

if __name__ == '__main__':

    url = "https://archive.ics.uci.edu/ml/machine-learning-databases/abalone/abalone.data"
    df = pd.read_csv(url, names=['Sex','Length','Diameter','Height','Whole weight','Shucked weight','Viscera weight','Shell weight','Rings'])
    label_map = {'M':0, 'F':1, 'I':2}

    features = ['Length','Diameter','Height','Whole weight','Shucked weight','Viscera weight','Shell weight','Rings']
    # Separating out the features
    x = df.loc[:, features].values
    # Separating out the target
    y = df.loc[:,['Sex']].values

    #print(x)

    # Standardizing the features
    x = MinMaxScaler().fit_transform(x)
    #print(x)

    pca = PCA()
    principalComponents = pca.fit_transform(x)
    x_pca = pca.transform(x)

    cov_mat = pca.get_covariance()
    print(cov_mat)
    relative_cov = pca.explained_variance_ratio_
    print(relative_cov)
    print(np.sum(relative_cov[:3])/np.sum(relative_cov))
    pca2 = PCA(n_components=2)
    principalComponents = pca2.fit_transform(x)
    principalDf = pd.DataFrame(data = principalComponents, columns = ['principal component 1', 'principal component 2'])
    x_pca = pca2.transform(x)
    finalDf = pd.concat([principalDf, df[['Sex']]], axis = 1)

    fig = plt.figure(figsize = (8,8))
    ax = fig.add_subplot(1,1,1) 
    ax.set_xlabel('Principal Component 1', fontsize = 15)
    ax.set_ylabel('Principal Component 2', fontsize = 15)
    ax.set_title('2 component PCA', fontsize = 20)
    targets = ['M', 'F', 'I']
    colors = ['r', 'g', 'b']
    for target, color in zip(targets,colors):
        indicesToKeep = finalDf['Sex'] == target
        ax.scatter(finalDf.loc[indicesToKeep, 'principal component 1'], finalDf.loc[indicesToKeep, 'principal component 2'], c = color, s = 50)
        ax.legend(targets)
        ax.grid()
    plt.show()




    df['Sex'].replace(label_map,inplace = True)
    Y = df['Sex']
    NMI = []

    for k in range(2, 9):
        clusters = {}
        for i in range(k):
            clusters[i] = []
        centroids = {}
        for i in range(k):
            centroids[i] = x_pca[i]
        for data in x_pca:
            euc_dist = []
            for j in range(k):
                euc_dist.append(np.linalg.norm(data - centroids[j]))
            clusters[euc_dist.index(min(euc_dist))].append(data)
        goahead = True
        while(goahead):
            new_centroids = recalculate_centroids(x_pca, clusters, k)
            if np.array_equal(centroids, new_centroids):
                goahead = False 
            Y_pred = []
            clusters = recalculate_clusters(x_pca, Y_pred, new_centroids, k)
            centroids = new_centroids
            print(goahead)
        NMI.append(nmi(Y, Y_pred))
    print(NMI)

    K = np.arange(2,9,dtype = int)
    plt.plot(K, NMI)
    plt.show()
    

    max_p = NMI.index(max(NMI)) + 2
    print("THe maximum value of NMI Occurs for k is",max_p)

   
    
