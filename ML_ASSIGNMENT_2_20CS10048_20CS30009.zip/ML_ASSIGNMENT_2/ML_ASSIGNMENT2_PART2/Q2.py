
# IMPORTS

from sklearn import preprocessing
from sklearn import utils
import os
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import math
from sklearn import svm
from csv import reader
# from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score
from sklearn.neural_network import MLPClassifier
from mlxtend.feature_selection import SequentialFeatureSelector
from mlxtend.classifier import EnsembleVoteClassifier
from sklearn.ensemble import RandomForestClassifier
from matplotlib import pyplot as plt
import warnings
warnings.filterwarnings("ignore")

# FUNCTION ENCODE FOR ENCODING  SEX 

def encode(dataframe):
  column = dataframe.iloc[:,0:1]
  for index in range(len(column)):
      cell = dataframe["Sex"][index]
      if cell == 'M': 
        cell = 1
      elif cell == 'F': 
        cell = 0
      elif cell == 'I': 
        cell = 2
      dataframe.loc[index,"Sex"] = cell
  return dataframe

def age(dataframe) :
  column = dataframe.iloc[:,8:9]
  for index in range(len(column)):
      cell = dataframe["Rings"][index]
      cell = cell + 1.5
      dataframe.loc[index,"Rings"] = cell
      
  return dataframe  


#  FUNCTION FOR NORMALIZATION OF DATA

# def standard_normalization(dataframe):
#   columns = dataframe.iloc[:,0:8]
#   #columns = list(dataframe.columns[:,1:])
#   for column in columns:
#     f = np.array(dataframe[column])
#     mean = f.mean()
#     std = f.std()
#     for index in range(len(f)):
#       cell = dataframe[column][index]
#       cell = (float)( cell - mean)/ std 
#       dataframe.loc[index,column] = cell
#   return dataframe

 # FUNCTION FOR NORMALIZATION OF DATA

def standard_normalization(dataframe):
  columns = dataframe.iloc[:,0:8]
  #columns = list(dataframe.columns[:,1:])
  for column in columns:
    f = np.array(dataframe[column])
    max = f.max()
    min = f.min()
    for index in range(len(f)):
      cell = dataframe[column][index]
      cell = (float)(( cell - min)/ (max - min))
      dataframe.loc[index,column] = cell
  return dataframe


# FUNCTION FOR SPLITTING DATA TO TEST AND TRAIN
def train_test_split(X,y):
    indices = np.arange(X.shape[0])
    np.random.shuffle(indices)
    split = int(X.shape[0] * 0.2)
    X_train = X.iloc[indices[split:]]
    y_train = y.iloc[indices[split:]]
    X_test = X.iloc[indices[:split]]
    y_test = y.iloc[indices[:split]]
    return X_train, y_train, X_test, y_test
  
# BACKWARD ELIMINATION METHOD

def backwardElimination(X_train, X_test, Y_train, Y_test, orig_accuracy, threshold):
    max_acc = orig_accuracy
    while(X_train.shape[1]>1 and max_acc > threshold):
        new_accuracy = []
        for feature in X_train.columns:
            new_X_train = X_train.drop(feature, axis = 1)
            new_X_test = X_test.drop(feature, axis = 1)
            mlp_clf = MLPClassifier(batch_size=32, solver='lbfgs', learning_rate_init=0.001, hidden_layer_sizes=(256, 16))
            mlp_clf.fit(new_X_train, Y_train)
            Y_pred = mlp_clf.predict(new_X_test)
            y = np.array(Y_test)
            mlp_accuracy = np.sum((Y_pred == y)/len(y))
            new_accuracy.append(mlp_accuracy)
        max_acc = max(new_accuracy)
        max_idx = new_accuracy.index(max_acc)
        if max_acc > threshold:
            X_train = X_train.drop(X_train.columns[max_idx], axis = 1)
            X_test = X_test.drop(X_test.columns[max_idx], axis = 1) 
    features = []
    for feature in X_train.columns:
        features.append(feature)
    print("BEST FEATURES :- ", features)
    print("\n")
    # print("\n Accuracy of the modified data :- ", max_acc)
    return X_train, X_test        

def max_vote(X_train, Y_train,X_test,Y_test):
    bs = 32
    r = 0.001
    clf1 = svm.SVC(kernel='poly', degree=2)
    clf2 = svm.SVC(kernel='rbf', degree=2)
    clf3 = MLPClassifier(batch_size=bs, solver='lbfgs', learning_rate_init= r, hidden_layer_sizes=(16, ))
    eclf = EnsembleVoteClassifier(clfs=[clf1, clf2, clf3], weights=[1, 1, 1])
    eclf.fit(X_train, Y_train)
    Y_pred = eclf.predict(X_test)
    print('******************************** Accuracy using max voting technique ***********************************')
    print('Accuracy acheived using max voting technique : ',accuracy_score(Y_test, Y_pred))


# MAIN FUNCTION
    
def main() :
    dataframe = pd.read_csv("abalone.csv",header = None, delimiter = ",")  
    dataframe.columns = ["Sex","Length","Diameter","Height","Whole weight","Shucked weight","Viscera weight","Shell weight","Rings"]
    ## print(dataframe.max())
    ## print(dataframe.min())
    encode(dataframe)                                    # encoding
    dataframe =standard_normalization(dataframe)         # standard normalization
    ##print(dataframe)
    
    ##print(dataframe)
    # print(dataframe.max())
    # print(dataframe.min())
    # # age(dataframe)
    # print(dataframe.max())
    # print(dataframe.min())

    X = dataframe.iloc[:, 0:7]
    Y = dataframe.iloc[:, 8:9]
    # print((X))
    # print((Y))
    
    # CONVERTING CONTINOUS DATA TO DISCRETE DATA


#convert y values to categorical values
    # lab = preprocessing.LabelEncoder()
    # Y = lab.fit_transform(Y)
    # # # print(type(Y))
    # # # print(type(X))
    # Y = pd.DataFrame(Y, columns = ["Rings"])
    # print((Y))


    dataframe['Rings'] = pd.cut(x=dataframe['Rings'], bins=[1,2, 3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30],
                     labels=[ '1','2', '3','4','5','6','7','8','9','10','11','12','13','14','15','16','17','18','19','20','21','22','23','24','25','26','27','28','29']) 
    # ## print(dataframe)
    X_train,  Y_train ,X_test, Y_test = train_test_split(X,Y)     # splitting the data

    # X_train,X_test,  Y_train , Y_test = train_test_split(X,Y)     # splitting the data
    # print(len(X_train))
    # ## print(len(Y_train))
    # print(len(X_test))
    ## print(type(Y_train))
    
    #print(dataframe)

    # BINARY SVM CLASSIFIER

    SVM_clf = svm.SVC(kernel = 'linear')
    SVM_clf.fit(X_train,Y_train)
    Y_pred = SVM_clf.predict(X_test)
    print("\n")
    print('******************************* SVM accuracy for linear kernel *************************************************')
    print('SVM accuracy for linear kernel :' , accuracy_score(Y_test,Y_pred))
    print("\n")

    SVM_clf = svm.SVC(kernel = 'poly', degree = 2)
    SVM_clf.fit(X_train,Y_train)
    Y_pred = SVM_clf.predict(X_test)
    print('******************************** SVM accuracy for quadratic kernel **********************************************')
    print('SVM accuracy for quadratic kernel :' , accuracy_score(Y_test,Y_pred))
    print("\n")

    SVM_clf = svm.SVC(kernel = 'rbf', degree = 2)
    SVM_clf.fit(X_train,Y_train)
    Y_pred = SVM_clf.predict(X_test)
    print('******************************** SVM accuracy for radial kernel **************************************************')
    print('SVM accuracy for radial kernel :' , accuracy_score(Y_test,Y_pred))
    print("\n")

    # MLP CLASSIFIER

    r = 0.001
    bs = 32

    MLP_clf1 =MLPClassifier(batch_size= bs , solver = 'lbfgs', learning_rate_init= r, hidden_layer_sizes=(16,))
    MLP_clf1.fit(X_train,Y_train)
    MLP_clf1.predict(X_test)
    print('******************************* MLP Accuracy using 1 hidden layer with 16 nodes *********************************')
    print("The mlp accuracy for batch size 32 , with 1 hidden layer and 16 nodes :", MLP_clf1.score(X_test,Y_test))
    print("\n")

    MLP_clf2 =MLPClassifier(batch_size= bs , solver = 'lbfgs', learning_rate_init= r, hidden_layer_sizes=(256,16))
    MLP_clf2.fit(X_train,Y_train)
    MLP_clf2.predict(X_test)
    k =  MLP_clf2.score(X_test,Y_test)
    print('******************************* MLP Accuracy using 2 hidden layers with 256 and 16 nodes *********************************')
    print("The mlp accuracy for batch size 32 , with 2 hidden layer with 256 and 16 nodes :", MLP_clf2.score(X_test,Y_test))
    print("\n")

    # LEARNING VS ACCURACY GRAPH

    lr = 0.1
    q = []
    for i in range(5):
        MLP_clf = MLPClassifier(batch_size=bs, solver='lbfgs', learning_rate_init=lr, hidden_layer_sizes=(256, 16))
        MLP_clf.fit(X_train, Y_train)
        Y_pred = MLP_clf.predict(X_test)
        q.append(accuracy_score(Y_test, Y_pred))
        lr = lr/10
    xpoints = np.array([0.1,0.01,0.001,0.0001,0.00001])
    ypoints = np.array([q[0],q[1],q[2],q[3],q[4]])
    # print(q)
    plt.plot(xpoints, ypoints)
    plt.savefig('plot.png')

    # BACKWARD ELIMINATION METHOD

    # bem = SequentialFeatureSelector(RandomForestClassifier(n_jobs= -1), k_features=(1,4),forward= False,floating=False,verbose= 2, scoring= 'accuracy',cv = 5).fit(X_train,Y_train)
    # print("\n")
    print('********************************* Features using  Backward Elimination Method ****************************')
    # print('Features using  backward elimination method :',bem.k_feature_names_)
    # print("\n")
    x_train, x_test = backwardElimination(X_train , X_test, Y_train, Y_test, k, 0.5)

    # ENSEMBLE LEARNING 

    max_vote(X_train,Y_train,X_test,Y_test)    
    print("\n")
    print("\n")





if __name__ == "__main__":
    main()